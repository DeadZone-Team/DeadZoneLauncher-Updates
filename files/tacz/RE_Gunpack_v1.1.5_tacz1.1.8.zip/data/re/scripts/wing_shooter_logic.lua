local M = {}
-- =======================================================================================
-- script by koei
-- ========================================================= ↓ 攻击信号 ↓ =================
function M.shoot(api)
    api:shootOnce(api:isShootingNeedConsumeAmmo())
    if (api:getFireMode() == BURST) then
        api:safeAsyncTask(function ()
        api:shootOnce(false)
        return false
    end,1*500,0,1)
    end
end
-- =================================================================================== ↓ 换弹 ↓ ===================
local function getReloadTimingFromParam(api, param)
    local cooldown = 0
    local feed = 0
    if (not api:hasAmmoInBarrel() and api:getAmmoAmount() >= 0) then
        if (api:getFireMode() == SEMI) then
            cooldown = param.empty_cooldown * 1000
            feed = param.empty_feed * 1000
        elseif (api:getFireMode() == BURST) then
            cooldown = param.empty_cooldown_burst * 1000
            feed = param.empty_feed_burst * 1000
        end
    else
        if (api:getFireMode() == SEMI) then
            cooldown = param.reload_cooldown * 1000
            feed = param.reload_feed * 1000
        elseif (api:getFireMode() == BURST) then
            cooldown = param.reload_cooldown_burst * 1000
            feed = param.reload_feed_burst * 1000
        end
    end
    if (cooldown == nil or feed == nil) then
        return nil
    end
    return cooldown, feed
end

function M.start_reload(api)
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            RELOAD = {
                RELOADED = false,
                FEED = 0,
                COOLDOWN = 0
            }
        }
    end
    cache.RELOAD.RELOADED = false
    local param = api:getScriptParams();
    cache.RELOAD.COOLDOWN, cache.RELOAD.FEED = getReloadTimingFromParam(api, param)
    api:cacheScriptData(cache)
    return true
end

function M.tick_reload(api)
    local cache = api:getCachedScriptData()
    local cooldown, feed = cache.RELOAD.COOLDOWN, cache.RELOAD.FEED
    local reload_time = api:getReloadTime()

    if (reload_time < feed) then
        return TACTICAL_RELOAD_FINISHING, feed - reload_time
    elseif (reload_time >= feed and reload_time <= cooldown) then
        if (not cache.RELOAD.RELOADED) then
            if (api:isReloadingNeedConsumeAmmo()) then
                if (api:getFireMode() == BURST) then
                    api:putAmmoInMagazine(math.floor(api:consumeAmmoFromPlayer(api:getNeededAmmoAmount()*2)/2))
                else
                    api:putAmmoInMagazine(api:consumeAmmoFromPlayer(api:getNeededAmmoAmount()))
                end
            else
                api:putAmmoInMagazine(api:getNeededAmmoAmount())
            end
            cache.RELOAD.RELOADED = true
        end
        return TACTICAL_RELOAD_FINISHING, cooldown - reload_time
    elseif (reload_time > cooldown) then
        return NOT_RELOADING, -1
    end
    api:cacheScriptData(cache)
end

return M